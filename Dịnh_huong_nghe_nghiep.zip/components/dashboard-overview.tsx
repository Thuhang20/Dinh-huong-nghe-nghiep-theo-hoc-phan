"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts"
import { Users, Target, TrendingUp, BookOpen, AlertCircle } from "lucide-react"
import { useData } from "@/contexts/data-context"
import { Alert, AlertDescription } from "@/components/ui/alert"

// Mock data for demonstration
const subjectScores = [
  { subject: "Toán học", score: 8.5 },
  { subject: "Lập trình", score: 9.2 },
  { subject: "Cơ sở dữ liệu", score: 7.8 },
  { subject: "Mạng máy tính", score: 8.1 },
  { subject: "Kỹ thuật phần mềm", score: 8.7 },
  { subject: "Trí tuệ nhân tạo", score: 7.5 },
]

const trendData = [
  { month: "T1", avgScore: 7.2 },
  { month: "T2", avgScore: 7.5 },
  { month: "T3", avgScore: 7.8 },
  { month: "T4", avgScore: 8.1 },
  { month: "T5", avgScore: 8.3 },
  { month: "T6", avgScore: 8.5 },
]

export function DashboardOverview() {
  const { studentData, careerData, isDataLoaded } = useData()

  // Calculate real statistics from uploaded data
  const totalStudents = studentData.length
  const totalCareers = careerData.length

  // Calculate average score from student data
  const calculateAverageScore = () => {
    if (studentData.length === 0) return 0

    const subjects = Object.keys(studentData[0]).filter(
      (key) => key !== "ID" && key !== "Họ tên" && !isNaN(Number(studentData[0][key])),
    )

    let totalScore = 0
    let totalCount = 0

    studentData.forEach((student) => {
      subjects.forEach((subject) => {
        const score = Number(student[subject])
        if (!isNaN(score)) {
          totalScore += score
          totalCount++
        }
      })
    })

    return totalCount > 0 ? (totalScore / totalCount).toFixed(1) : 0
  }

  // Generate subject scores from real data
  const generateSubjectScores = () => {
    if (studentData.length === 0) return subjectScores

    const subjects = Object.keys(studentData[0]).filter(
      (key) => key !== "ID" && key !== "Họ tên" && !isNaN(Number(studentData[0][key])),
    )

    return subjects.slice(0, 6).map((subject) => {
      const scores = studentData.map((student) => Number(student[subject])).filter((score) => !isNaN(score))
      const avgScore = scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 0
      return {
        subject: subject.length > 15 ? subject.substring(0, 15) + "..." : subject,
        score: Number(avgScore.toFixed(1)),
      }
    })
  }

  const realSubjectScores = generateSubjectScores()
  const averageScore = calculateAverageScore()

  // Show data loading message if no data
  if (!isDataLoaded) {
    return (
      <div className="space-y-6">
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Chưa có dữ liệu để hiển thị. Vui lòng tải lên dữ liệu điểm số sinh viên và nghề nghiệp trong mục "Nhập dữ
            liệu".
          </AlertDescription>
        </Alert>

        {/* Show placeholder stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="opacity-50">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Tổng sinh viên</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-muted-foreground">--</div>
              <p className="text-xs text-muted-foreground">Chưa có dữ liệu</p>
            </CardContent>
          </Card>

          <Card className="opacity-50">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Nghề được gợi ý</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-muted-foreground">--</div>
              <p className="text-xs text-muted-foreground">Chưa có dữ liệu</p>
            </CardContent>
          </Card>

          <Card className="opacity-50">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Điểm TB chung</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-muted-foreground">--</div>
              <p className="text-xs text-muted-foreground">Chưa có dữ liệu</p>
            </CardContent>
          </Card>

          <Card className="opacity-50">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Học phần</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-muted-foreground">--</div>
              <p className="text-xs text-muted-foreground">Chưa có dữ liệu</p>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards with real data */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tổng sinh viên</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{totalStudents.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Từ dữ liệu đã tải lên</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Nghề được gợi ý</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-secondary">{totalCareers}</div>
            <p className="text-xs text-muted-foreground">Nghề nghiệp có sẵn</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Điểm TB chung</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-chart-1">{averageScore}</div>
            <p className="text-xs text-muted-foreground">Trung bình tất cả học phần</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Học phần</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-chart-4">{realSubjectScores.length}</div>
            <p className="text-xs text-muted-foreground">Đã được phân tích</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts with real data */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="font-heading">Điểm trung bình theo học phần</CardTitle>
            <CardDescription>Tổng quan điểm số các học phần từ dữ liệu thực</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={realSubjectScores}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="subject" angle={-45} textAnchor="end" height={80} fontSize={12} />
                <YAxis domain={[0, 10]} />
                <Tooltip />
                <Bar dataKey="score" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="font-heading">Xu hướng điểm số</CardTitle>
            <CardDescription>Biến động điểm trung bình theo thời gian</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis domain={[6, 10]} />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="avgScore"
                  stroke="hsl(var(--primary))"
                  strokeWidth={3}
                  dot={{ fill: "hsl(var(--primary))", strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="font-heading">Hoạt động gần đây</CardTitle>
          <CardDescription>Các phân tích và gợi ý mới nhất</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center space-x-4 p-3 bg-muted rounded-lg">
              <div className="w-2 h-2 bg-chart-1 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">Đã tải lên dữ liệu {totalStudents} sinh viên</p>
                <p className="text-xs text-muted-foreground">Vừa xong</p>
              </div>
            </div>

            <div className="flex items-center space-x-4 p-3 bg-muted rounded-lg">
              <div className="w-2 h-2 bg-chart-2 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">Cập nhật {totalCareers} nghề nghiệp trong hệ thống</p>
                <p className="text-xs text-muted-foreground">Vừa xong</p>
              </div>
            </div>

            <div className="flex items-center space-x-4 p-3 bg-muted rounded-lg">
              <div className="w-2 h-2 bg-chart-4 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">Hệ thống sẵn sàng cho phân tích và gợi ý</p>
                <p className="text-xs text-muted-foreground">Vừa xong</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
